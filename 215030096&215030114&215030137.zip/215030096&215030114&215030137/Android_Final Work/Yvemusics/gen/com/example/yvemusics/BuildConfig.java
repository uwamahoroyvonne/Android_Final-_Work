/** Automatically generated file. DO NOT MODIFY */
package com.example.yvemusics;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}