package com.example.layouts;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;


public class MainActivityLinear extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainlinear);
        Button close=(Button)findViewById(R.id.btnclose);
        close.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
			finish();
			System.exit(0);
				
			}
		});
  
}
    }
